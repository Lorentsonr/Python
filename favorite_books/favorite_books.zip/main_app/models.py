from django.db import models
import re

# Create your models here.
class UserManager(models.Manager):
    def validate_register(self, postData):
        errors = {}
        if len(postData['first_name']) < 2:
            errors['first_name'] = "First Name must be longer than 2 characters"
        if len(postData['last_name']) < 2:
            errors['last_name'] = "Last Name must be longer than 2 characters"
        # EMAIL PATTERN
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(postData['email']):               
            errors['email_pattern'] = "Invalid email address!"
        # UNIQUE EMAIL
        user_list = User.objects.filter(email = postData['email'])
        if len(user_list) > 0:
            errors['email_duplicate'] = "Account already exists with email"
        # PASSWORD GREATER THAN 8
        if len(postData['password']) < 8:
            errors['password'] = "Password must be greater than 8"
        # PASSWORD MATCHES CONFIRM PASSWORD
        if postData['password'] != postData['confirm_password']:
            errors['confirm_password'] = "Password and Confirm Password must match"
        return errors

class BookManager(models.Manager):
    def validate_book(self, postData):
        book_errors = {}
        if len(postData['title']) < 1:
            book_errors['title'] = "Title is required"
        if len(postData['desc']) < 5:
            book_errors['desc'] = "Description must be longer than 5 characters"
        return book_errors

class User(models.Model):
    first_name = models.CharField(max_length = 255)
    last_name = models.CharField(max_length = 255)
    email = models.EmailField(max_length = 255)
    password = models.CharField(max_length = 255)

    # liked_books = a list of books a given user likes
    # books_uploaded = a list of books uploaded by a given user

    objects = UserManager()

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Book(models.Model):
    title = models.CharField(max_length = 255)
    desc = models.TextField()

    uploaded_by = models.ForeignKey(User, related_name="books_uploaded", on_delete = models.CASCADE)
        # the user who uploaded a given book
    users_who_like = models.ManyToManyField(User, related_name="liked_books")
        # a list of users who like a given book

    objects= BookManager()

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)