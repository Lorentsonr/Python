from  django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('register_user', views.register_user),
    path('login', views.login),
    path('books', views.home),
    path('add_book', views.add_book),
    path('books/<int:id>', views.view_book),
    path('add_to_favorites', views.add_favorite),
    path('unfavorite', views.unfavorite),
    path('update_book', views.update_book),
    path('delete_book', views.delete_book),
    path('logout', views.logout)
]