from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User, Book
import bcrypt

# Create your views here.
def index(request):
    return render(request, "index.html")

def register_user(request):
    # VALIDATE USER INFO
    errors = User.objects.validate_register(request.POST)
    # USER DOESNT PASS VALIDATION
    if errors:
        for key, value in errors.items():
            messages.error(request,value)
        return redirect('/')
    # USER PASSES VALIDATION
    hashed_pw = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt() ).decode()
    new_user = User.objects.create(
        first_name = request.POST['first_name'],
        last_name = request.POST['last_name'],
        email = request.POST['email'],
        password = hashed_pw
    )
    # STORE NEW USERS ID IN SESSION
    request.session['user_id'] = new_user.id
    return redirect('/books')

def login(request):
    user = User.objects.filter(email = request.POST['email'])
    if user:
        logged_user = user[0]
        if bcrypt.checkpw(request.POST['password'].encode(), logged_user.password.encode()):
            request.session['user_id'] = logged_user.id #VERY IMPORTANT FOR THIS TO MATCH LINE 28
            return redirect('/books')
        messages.error(request, "INVALID CREDENTIALS")
        return redirect('/')
    messages.error(request, "Email doesn't exist. Please register account")
    return redirect('/')

def home(request):
    user_id = int(request.session['user_id'])
    context={
        "user_logged_in" : User.objects.get(id=user_id),
        "all_books" : Book.objects.all(),
    }
    return render(request, "Home.html", context)

def add_book(request): 
    errors = Book.objects.validate_book(request.POST)
    if errors:
        for key, value in errors.items():
            messages.error(request,value)
        return redirect('/books')
    user_that_added_book = int(request.POST['uploaded_by_id'])
    this_user = User.objects.get(id=user_that_added_book)
    new_book = Book.objects.create(
        title = request.POST['title'],
        desc = request.POST['desc'],
        uploaded_by = this_user
    )
    #When book is created auto-add to the favorite
    this_book = new_book.id
    this_user = User.objects.get(id=int(request.POST['uploaded_by_id']))
    this_user.liked_books.add(this_book)
    return redirect(f'/books/{new_book.id}')

def view_book(request, id):
    user_id = int(request.session['user_id'])
    context={
        "user_logged_in" : User.objects.get(id=user_id),
        "current_book" : Book.objects.get(id=id),
    }
    return render(request, "view_book.html", context)

def add_favorite(request):
    book_id = int(request.POST['favorited_book'])
    this_book = Book.objects.get(id=int(request.POST['favorited_book']))
    this_user = User.objects.get(id=int(request.POST['this_user_id']))
    this_user.liked_books.add(this_book)
    return redirect(f'/books/{book_id}')

def unfavorite(request):
    book_id = int(request.POST['unfavorited_book'])
    this_book = Book.objects.get(id=int(request.POST['unfavorited_book']))
    this_user = User.objects.get(id=int(request.POST['this_user_id']))
    this_user.liked_books.remove(this_book)
    return redirect(f'/books/{book_id}')

def update_book(request):
    book_id_to_upd = int(request.POST['book_to_upd'])
    errors = Book.objects.validate_book(request.POST)
    if errors:
        for key, value in errors.items():
            messages.error(request,value)
        return redirect(f'/books/{book_id_to_upd}')
    upd_this_book = Book.objects.get(id=book_id_to_upd)
    upd_this_book.title = request.POST['title']
    upd_this_book.desc = request.POST['desc']
    upd_this_book.save()
    return redirect(f'/books/{book_id_to_upd}')

def delete_book(request):
    book_id_delete = int(request.POST['book_to_delete'])
    delete_this_book = Book.objects.get(id=book_id_delete)
    delete_this_book.delete()
    return redirect('/books')

def logout(request):
    request.session.flush()
    return redirect('/')