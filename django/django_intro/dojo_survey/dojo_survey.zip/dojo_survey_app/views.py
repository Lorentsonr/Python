from django.shortcuts import render, redirect

def index(request):
    return render(request, "index.html")

def info(request):
    user_name = request.POST['name']
    user_location = request.POST['location']
    user_languge = request.POST['language']
    user_comment = request.POST['comment']
    dict ={
        "template_name" : user_name,
        "template_location" : user_location,
        "template_language" : user_languge,
        "template_comment" : user_comment
    }
    return render(request, "result.html", dict)
